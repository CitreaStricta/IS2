from flask_wtf import FlaskForm

class SurveyForm(FlaskForm):
    pass