# IS2

Como ejecutar:
Iniciar env ->
en el directorio /IS2 actualizar dependencias con "pip3 install -r requirements.txt" ->
ir al directorio /flaskr ->
en consola ejecutar el comando "python entrypoint.py" 

Usar "python3 entrypoint.py" tambien funciona
